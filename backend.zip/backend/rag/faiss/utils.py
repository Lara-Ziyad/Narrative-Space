def l2_to_score(distance: float) -> float:
    return 1.0 / (1.0 + float(distance))
