from .retriever import FaissRetriever

__all__ = ["FaissRetriever"]
