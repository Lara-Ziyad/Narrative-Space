from .routes import models_bp

__all__ = []




